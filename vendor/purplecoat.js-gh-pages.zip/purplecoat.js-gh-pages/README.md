# :womans_clothes: Purplecoat.js :womans_clothes:

Purplecoat.js lets you create labeled overlays that can be triggered with a click. And you don't need to write a single line of Javascript.

## [View Demo and Documentation &rarr;](http://ellekasai.github.io/purplecoat.js)

![](http://f.cl.ly/items/10023K3W2A3F1y423x2c/Screen%20Recording%202014-11-09%20at%2000%3A38.gif)

## Author & License

Elle Kasai

- [Website](http://ellekasai.com/about)
- [Twitter](http://twitter.com/ellekasai)

[MIT License](http://ellekasai.mit-license.org).
